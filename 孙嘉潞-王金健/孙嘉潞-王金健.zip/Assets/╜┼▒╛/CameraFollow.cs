﻿using UnityEngine;


public class CameraFollow : MonoBehaviour
{
    public Transform target; // 跟随的目标

    private Vector3 _offset; // 相机与目标的偏移量

    private void Start()
    {
        // 计算相机与目标的偏移量
        _offset = transform.position - target.position;
    }

    private void LateUpdate()
    {
        // 相机位置 = 目标位置 + 偏移量
        transform.position = target.position + _offset;
    }
}
