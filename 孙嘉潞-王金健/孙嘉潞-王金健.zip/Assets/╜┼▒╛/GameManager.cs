﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public float addPlatformDis; // 生成平台的距离 当小球与最后一个平台的距离小于该值时 生成新的平台
    public float desPlatformDis; // 销毁平台的距离 当小球与第一个平台的距离大于该值时 销毁第一个平台
    public Text overNowDisText; // 游戏结束时显示的当前距离文本UI。
    public Text overMaxDisText; // 游戏结束时显示的最远距离文本UI。
    public GameObject gameOverPanel; // 游戏结束时显示的面板UI。
    
    public static GameManager Instance; // 单例
    
    private Transform _ballTr; // 小球的Transform组件
    private PlatformGenerationManagement _pgm; // 平台生成管理组件

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        _ballTr = FindObjectOfType<BallControl>().transform;
        _pgm = FindObjectOfType<PlatformGenerationManagement>();
    }

    private void Update()
    {
        // 当小球与最后一个平台的距离小于addPlatformDis时 生成新的平台
        if (Vector3.Distance(_ballTr.position, _pgm.GetEndPlatformPos()) < addPlatformDis)
        {
            _pgm.GeneratePlatform();
        }

        // 当小球与第一个平台的距离大于desPlatformDis时 销毁第一个平台
        Vector3 firsetPlatformPos = _pgm.GetFirstPlatformPos();
        if (Vector3.Distance(firsetPlatformPos, _ballTr.position) > desPlatformDis && firsetPlatformPos.z < _ballTr.position.z)
        {
            _pgm.DesPlatform(0);
        }
    }

    // 游戏结束
    public void GameOver(int nowDis, int maxDis)
    {
        // 更新最远距离
        maxDis = nowDis > maxDis ? nowDis : maxDis;
        overNowDisText.text = "当前距离: " + nowDis;
        overMaxDisText.text = "最远距离: " + maxDis;
        
        // 保存最远距离
        PlayerPrefs.SetInt("MaxDis", maxDis);
        gameOverPanel.SetActive(true);
        Time.timeScale = 0; // 暂停游戏
    }

    // 跳转到开始场景
    public void GotoStartScene()
    {
        // 恢复游戏速度
        Time.timeScale = 1;
        SceneManager.LoadScene(0);
    }
}
