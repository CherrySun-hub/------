﻿using UnityEngine;


public class StartManager : MonoBehaviour
{   
    
    // 跳转到游戏场景
    public void GotoGameScene()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(1);
    }
    
    // 退出游戏
    public void ExitGame()
    {
        Application.Quit();
    }
}
