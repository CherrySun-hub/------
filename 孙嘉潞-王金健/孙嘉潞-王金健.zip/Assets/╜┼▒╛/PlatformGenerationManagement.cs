﻿using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 平台生成管理器,平台生成的同时也要生成左右两边的背景，以及平台上的陷阱,主要逻辑是设定平台之间的间隔、偏移角度以及落差。
/// 在生成平台时，首先计算以上一个平台的间隔。然后计算平台的偏移角度，偏移角度的范围为-offsetAngle到offsetAngle之间。
/// 然后计算平台的落差，落差的范围为0到dropDistance之间。然后计算平台的数量，平台数量的范围为platformCountRange。
/// 然后在偶数平台的左右生成背景。背景的生成概率为probability。背景的大小范围为scaleRange。背景的上下偏移范围为upDownOffsetRange。
/// 最后在平台上生成陷阱。陷阱的生成概率为trapProbability。
/// </summary>
public class PlatformGenerationManagement : MonoBehaviour
{
    public GameObject platformPrefab; // 平台预制体
    public float tiltAngle = 15f; // 平台倾斜角度
    public float platformWidth = 1f; // 平台长度
    public Vector3 startPos; // 初始位置
    public float dropDistance = 10f; // 平台与平台之间的落差
    public float interval = 5f; // 生成平台的间隔
    public float offsetAngle = 45f; // 平台生成的角度偏移量
    public Vector2Int platformCountRange = new Vector2Int(5, 10); // 平台数量范围
    private List<List<GameObject>> _platforms = new List<List<GameObject>>(); // 保存生成的平台
    private Vector3 dir; // 平台生成的方向

    public GameObject[] backgroundItems; // 背景物品
    public Vector2 scaleRange; // 背景物品大小范围
    public float backgroundDis; // 背景物品与平台的距离
    public Vector2 upDownOffsetRange; // 背景物品上下偏移范围
    [Range(0,1)]
    public float probability; // 背景物品生成概率
    private List<List<GameObject>> _backgroundItemList = new List<List<GameObject>>(); // 保存生成的背景物品

    private BallControl _ballControl; // 小球控制组件

    public GameObject trapObj; // 陷阱物品
    [Range(0,1)]
    public float trapProbability; // 陷阱物品生成概率
    private List<List<GameObject>> _trapObjs = new List<List<GameObject>>(); // 保存生成的陷阱物品
    
    private void Start()
    {
        _ballControl = FindObjectOfType<BallControl>();
        dir = Quaternion.Euler(tiltAngle, 0, 0) * Vector3.forward;
        InitPlatforms();

    }
    
    // 初始化平台
    private void InitPlatforms()
    {
        int startCount = 5; // 初始平台数量
        
        List<GameObject> platforms = new List<GameObject>();
        List<GameObject> backgrounds = new List<GameObject>();
        List<GameObject> traps = new List<GameObject>();
        
        // 生成初始平台 用于游戏开始时的平台
        var platform = Instantiate(platformPrefab);
        platform.transform.position = startPos;
        platform.transform.rotation = Quaternion.Euler(tiltAngle, 0, 0);
        
        // 添加碰撞体 并设置碰撞体的中心位置和大小 使该碰撞体能完整覆盖当前生成的平台数量 
        BoxCollider boxCollider = platform.AddComponent<BoxCollider>();
        boxCollider.center = new Vector3( 0, -0.1f, (startCount - 1)/2f);
        Vector3 size = boxCollider.size;
        boxCollider.size = new Vector3(size.x, size.y, startCount);
        platforms.Add(platform);
        
        for (int i = 1; i < startCount; i++)
        {
            // 生成平台
            platform = Instantiate(platformPrefab);
            platform.transform.position = startPos + dir * platformWidth * i;
            platform.transform.rotation = Quaternion.Euler(tiltAngle, 0, 0);
            platforms.Add(platform);

            // 生成背景物品 生成概率为probability 每隔两个平台生成一个背景物品 背景物品的位置为平台位置的左右两边 背景物品的大小为scaleRange范围内的随机值 背景物品的上下偏移为upDownOffsetRange范围内的随机值
            if (i > 0 && i % 2 == 0 && Random.value < probability)
            {
                var backgroundItem = Instantiate(backgroundItems[Random.Range(0, backgroundItems.Length)]);
                backgroundItem.transform.position = platform.transform.position + backgroundDis * Vector3.right * (Random.value > 0.5f ? 1 : -1);
                backgroundItem.transform.localScale = Vector3.one * Random.Range(scaleRange.x, scaleRange.y);
                backgroundItem.transform.position += Vector3.up * Random.Range(upDownOffsetRange.x, upDownOffsetRange.y);
                backgrounds.Add(backgroundItem);
            }

            // 生成陷阱物品 生成概率为trapProbability 每隔两个平台生成一个陷阱物品 陷阱物品的位置为平台位置的左右两边 陷阱物品的大小为0.4f 陷阱物品的父物体为平台
            if (i%2 > 0 && Random.value < trapProbability)
            {
                var trap = Instantiate(trapObj, platform.transform);
                trap.transform.localPosition = Random.value > 0.5f ? new Vector3(-0.4f,0,0) : Vector3.zero;
                trap.transform.localScale = new Vector3(0.4f, 0.4f, 0.4f);
                traps.Add(trap);
            }
            
        }
        _platforms.Add(platforms);
        _backgroundItemList.Add(backgrounds);
        _trapObjs.Add(traps);
    }
    
    // 获取最后一个平台的位置
    public Vector3 GetEndPlatformPos()
    {
        return _platforms[_platforms.Count - 1][0].transform.position;
    }
    
    // 获取第1个平台的末尾位置
    public Vector3 GetFirstPlatformPos()
    {
        return _platforms[0][_platforms[0].Count - 1].transform.position;
    }

    // 删除平台 同时要删除该平台左右的背景和陷阱
    public void DesPlatform(int index)
    {
        if (_platforms.Count <= 1)
        {
            return;
        }
        if (_platforms.Count > index)
        {
            // 删除平台
            foreach (var platform in _platforms[index])
            {
                Destroy(platform);
            }

            // 删除背景
            foreach (var item in _backgroundItemList[index])
            {
                Destroy(item);
            }
            
            // 删除陷阱
            foreach (var trap in _trapObjs[index])
            {
                Destroy(trap);
            }
            _platforms.RemoveAt(index);
            _backgroundItemList.RemoveAt(index);
            _trapObjs.RemoveAt(index);
        }
    }
    
    // 生成平台 生成平台数量在platformCountRange范围内 生成平台的位置为上一个平台的末尾位置 + 一个随机角度的偏移量 * 平台长度 * 速度限制/15
    public void GeneratePlatform()
    {
        int startCount = Random.Range(platformCountRange.x, platformCountRange.y);
        List<GameObject> platforms = new List<GameObject>();
        List<GameObject> backgrounds = new List<GameObject>();
        List<GameObject> traps = new List<GameObject>();
        var platform = Instantiate(platformPrefab);
        int lastCunt = _platforms[_platforms.Count - 1].Count;
        Vector3 lastEndPos = _platforms[_platforms.Count - 1][lastCunt - 1].transform.position;
        
        // 这里的平台生成与上面的初始化InitPlatforms大同小异 唯一的区别在于后面生成的平台需要计算与前面的平台的偏移位置
        Vector3 nowStartPos = lastEndPos + Quaternion.Euler(0, Random.Range(-offsetAngle, offsetAngle),0) * dir * interval * (_ballControl.nowSpeedLimit/15);
        nowStartPos.y -= dropDistance;
        
        platform.transform.position = nowStartPos;
        platform.transform.rotation = Quaternion.Euler(tiltAngle, 0, 0);
        BoxCollider boxCollider = platform.AddComponent<BoxCollider>();
        boxCollider.center = new Vector3( 0, -0.1f, (startCount - 1)/2f);
        Vector3 size = boxCollider.size;
        boxCollider.size = new Vector3(size.x, size.y, startCount);
        platforms.Add(platform);
        for (int i = 1; i < startCount; i++)
        {
            platform = Instantiate(platformPrefab);
            platform.transform.position = nowStartPos + dir * platformWidth * i;
            platform.transform.rotation = Quaternion.Euler(tiltAngle, 0, 0);
            platforms.Add(platform);    
            
            if (i > 0 && i % 2 == 0 && Random.value < probability)
            {
                var backgroundItem = Instantiate(backgroundItems[Random.Range(0, backgroundItems.Length)]);
                backgroundItem.transform.position = platform.transform.position + backgroundDis * Vector3.right * (Random.value > 0.5f ? 1 : -1);
                backgroundItem.transform.localScale = Vector3.one * Random.Range(scaleRange.x, scaleRange.y);
                backgroundItem.transform.position += Vector3.up * Random.Range(upDownOffsetRange.x, upDownOffsetRange.y);
                backgrounds.Add(backgroundItem);
            }
            
            if (i%2 > 0 && Random.value < trapProbability)
            {
                var trap = Instantiate(trapObj, platform.transform);
                trap.transform.localPosition = Random.value > 0.5f ? new Vector3(-0.4f,0,0) : Vector3.zero;
                trap.transform.localScale = new Vector3(0.4f, 0.4f, 0.4f);
                traps.Add(trap);
            }
        }
        _platforms.Add(platforms);
        _backgroundItemList.Add(backgrounds);
        _trapObjs.Add(traps);
    }
}
