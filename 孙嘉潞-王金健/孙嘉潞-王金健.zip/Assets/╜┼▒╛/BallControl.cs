﻿using System;
using UnityEngine;
using UnityEngine.UI;


public class BallControl : MonoBehaviour
{
    public AnimationCurve forwardSpeedLimit; // 前进速度限制曲线 通过游戏时间读取对应的限制速度 用于控制小球的前进速度
    public float moveSpeed = 10f; // 左右移动速度 用于按住A/D键时左右移动
    public float declineSpeed; // 快速下落速度 用于按住S键时快速下落
    public float jumpForce = 10f; // 跳跃力 用于按下空格键时跳跃
    public float detectionRadius; // 地面检测半径 用于检测小球是否在地面上
    public LayerMask groundLayer; // 地面层级 用于检测小球是否在地面上
    public float lifeTime; // 生命时间 当小球离开地面，超过该时间时，游戏结束。
    public Text nowDisText; // 当前距离文本UI
    public Text maxDisText; // 最远距离文本UI
    
    [HideInInspector]
    public float nowSpeedLimit; // 当前速度限制 用于控制小球的前进速度

    private Rigidbody _rigidbody; // 小球刚体组件
    private float _startTime; // 游戏开始时间
    private float _nowLifeTime; // 当前生命时间
    private bool _isGround; // 是否在地面上
    
    private float _maxDis; // 最远距离
    private float _nowDis; // 当前距离
    private float startZ; // 初始位置的z坐标
    
    private void Start()
    {
        _startTime = Time.time;
        _nowLifeTime = lifeTime;
        _rigidbody = GetComponent<Rigidbody>();
        startZ = transform.position.z;
        _maxDis = PlayerPrefs.HasKey("MaxDis") ? PlayerPrefs.GetInt("MaxDis") : 0; // 读取最远距离 如果没有则为0
        nowDisText.text = "当前距离: 0";
        maxDisText.text = "最远距离: " + _maxDis;
    }

    private void Update()
    {
        if (_nowLifeTime < 0)
        {
            return;
        }
        
        // 球形射线检测小球是否在地面上
        _isGround = Physics.CheckSphere(transform.position, detectionRadius, groundLayer);

        // 如果在地面上 则重置生命时间 否则生命时间减少 生命时间小于零时游戏结束
        if (_isGround)
        {
            _nowLifeTime = lifeTime;
        }
        else
        {
            _nowLifeTime -= Time.deltaTime;
            if (_nowLifeTime <= 0)
            {
                GameManager.Instance.GameOver((int)_nowDis, (int)_maxDis);
            }
        }
        
        // 如果按下空格键如果小球在地面上 则对刚体施加一个跳跃的力
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (_isGround)
            {
                _rigidbody.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
            }
        }
        
        // 如果按下A/D键 则对小球进行左右移动
        float horizontal = Input.GetAxisRaw("Horizontal");
        transform.position += new Vector3(horizontal * moveSpeed * Time.deltaTime, 0, 0);

        // 如果按下S键 则对小球进行快速下落
        if (Input.GetKey(KeyCode.S))
        {
            if (!_isGround)
            {
                transform.position += Vector3.down * (declineSpeed * Time.deltaTime);
            }
        }

        // 根据游戏时间计算当前速度限制
        nowSpeedLimit = forwardSpeedLimit.Evaluate(Time.time - _startTime);
        if (_rigidbody.velocity.sqrMagnitude > 0)
        {
            // 根据当前速度限制对刚体速度进行限制
            _rigidbody.velocity = _rigidbody.velocity.normalized * nowSpeedLimit;
        }
    }
    
    private void LateUpdate()
    {
        // 计算当前距离和最远距离
        _nowDis = transform.position.z - startZ;
        _maxDis = _nowDis > _maxDis ? _nowDis : _maxDis;
        // 更新当前距离与最远距离的文本UI
        nowDisText.text = "当前距离: " + (int)_nowDis;
        maxDisText.text = "最远距离: " + (int)_maxDis;
    }
    
    
    private void OnCollisionEnter(Collision collision)
    {
        // 如果碰到的是陷阱 则游戏结束
        if (collision.gameObject.CompareTag("Trap"))
        {
            GameManager.Instance.GameOver((int)_nowDis, (int)_maxDis);
        }
    }
}
